# SENG-300-Project-Iteration 2
Group 5

Functionality to do list:
* Weight Discrepancy -- Mai & Brandon (done)
* Enter Membership Number by Typing -- Rose & Saja & Benjamin (done)
* Add Own Bags -- Mai & Brandon (done)
* Purchase Bags -- Mai & Brandon (done)
* Pay with Cash -- Jason & Jesse (done)
* Pay with Debit Card -- Eusa & Simrat (done)
* Add Item [after partial payment] - Jason & Jesse (done)
* Print Receipt (Low Paper & Low Ink) -- Benjamin & Dayee (done)


Testing to do list: 
* Weight Discrepancy -- GUI (not required??)
* Enter Membership Number by Typing -- Rose (done)
* Add Own Bags -- Mai & Brandon & Dayee(done)
* Purchase Bags -- Mai & Brandon & Dayee(done) 
* Pay with Cash -- Jason & Jesse (in-progress)
* Pay with Debit/Credit Card -- Eusa  and Simrat (done)
* Add Item [after partial payment] - Jason & Jesse (unknown)
* Print Receipt (Low Paper & Low Ink) -- Benjamin & Dayee (done)
