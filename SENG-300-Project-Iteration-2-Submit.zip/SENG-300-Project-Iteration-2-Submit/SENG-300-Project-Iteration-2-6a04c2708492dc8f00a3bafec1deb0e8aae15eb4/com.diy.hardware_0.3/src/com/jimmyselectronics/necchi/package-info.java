/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * Our Necchi line of barcode scanners is the preferred choice for discerning
 * friends of mine. Handheld units and combinations with electronic scales from
 * our Virgilio line, your satisfaction will be more than supercazzora!
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics.necchi;
