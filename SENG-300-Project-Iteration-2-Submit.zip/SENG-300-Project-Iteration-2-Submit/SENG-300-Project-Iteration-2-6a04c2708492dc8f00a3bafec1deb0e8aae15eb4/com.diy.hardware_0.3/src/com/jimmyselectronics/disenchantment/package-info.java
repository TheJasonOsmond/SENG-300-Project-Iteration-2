/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * You will be all over our Disenchantment line of touch screens; you won't
 * believe your eyes! Suitable for all applications, you have but to add your
 * custom graphical user interface. Currently, we only support Java Swing, but
 * expect added support for Java FX in the near future.
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics.disenchantment;