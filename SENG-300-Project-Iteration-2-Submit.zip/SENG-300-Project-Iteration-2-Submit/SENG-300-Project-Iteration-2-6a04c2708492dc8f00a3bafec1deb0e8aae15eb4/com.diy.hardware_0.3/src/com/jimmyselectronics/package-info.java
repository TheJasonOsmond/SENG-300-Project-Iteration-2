/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * Our squirrels are fed a rich diet of hazelnuts to ensure that they be in top
 * form and never get tired while they are working for you!
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics;