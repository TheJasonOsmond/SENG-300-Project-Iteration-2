/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * Our O-Pee-Chee line of electronic card readers is 100% free of cheap bubble
 * gum, but 100% sure to satisfy all your card reading needs! Tap, insert,
 * swipe: we support all the most common interaction modes.
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics.opeechee;