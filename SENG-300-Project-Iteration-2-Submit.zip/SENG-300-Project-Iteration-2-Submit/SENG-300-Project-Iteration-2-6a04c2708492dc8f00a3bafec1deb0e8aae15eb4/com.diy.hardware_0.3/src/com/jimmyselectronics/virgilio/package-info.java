/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * Born under the right sign, our Virgilio line of electronic scales will
 * release your inner poet!  Designed for big jobs and small, combination with
 * our Necchi line of barcode scanners is easily supported.
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics.virgilio;