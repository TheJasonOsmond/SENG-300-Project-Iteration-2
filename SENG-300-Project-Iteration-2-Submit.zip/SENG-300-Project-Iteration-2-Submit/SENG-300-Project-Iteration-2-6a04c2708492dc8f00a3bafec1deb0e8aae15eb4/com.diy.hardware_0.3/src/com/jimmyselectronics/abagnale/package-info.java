/**
 * Welcome to Jimmy's Electronics, your one-stop shopping experience for high
 * quality electronic components.
 * <p>
 * Our Abagnale line of printers suits all needs, big and small. But we remind
 * you that counterfeiting is illegal, and we deny all responsibility for misuse
 * of our components.
 * 
 * @author Jimmy's Electronics LLP
 */
package com.jimmyselectronics.abagnale;