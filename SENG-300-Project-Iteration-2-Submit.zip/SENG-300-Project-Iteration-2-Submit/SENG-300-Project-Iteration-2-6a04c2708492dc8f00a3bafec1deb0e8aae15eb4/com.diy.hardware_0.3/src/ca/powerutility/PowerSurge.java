package ca.powerutility;

/**
 * Simulates a power surge.
 */
public class PowerSurge extends Error {
	private static final long serialVersionUID = -3127157849326759714L;
}
